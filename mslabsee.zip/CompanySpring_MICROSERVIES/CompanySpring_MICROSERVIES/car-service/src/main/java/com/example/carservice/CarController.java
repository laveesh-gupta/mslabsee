package com.example.carservice;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/car")
@RestController
public class CarController {
    private List<Car> cars = Arrays.asList(
            new Car(1, "Maruti"),
            new Car(2, "Mahindra"));
    
    @GetMapping
    public List<Car> getAllCars() {
        return cars;
    }
    
    @GetMapping("/{id}")
    public Car getCustomerById(@PathVariable int id) {
        return cars.stream()
                        .filter(car -> car.getId() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}