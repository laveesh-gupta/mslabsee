package com.example.userservice;
public class User {
    private final int id;
    private final int carId;
    private final String name;

    public User(final int id, final int carId, final String name) {
        this.id = id;
        this.carId = carId;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public int getCarId() {
        return carId;
    }

    public String getName() {
        return name;
    }
}